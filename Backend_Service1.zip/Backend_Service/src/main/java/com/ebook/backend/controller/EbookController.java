package com.ebook.backend.controller;

import java.util.List;
import org.springframework.web.bind.annotation.*;

import com.ebook.backend.model.Ebook;
import com.ebook.backend.service.EbookService;

@RestController
@RequestMapping("/api/ebooks")
@CrossOrigin(origins = "http://localhost:3000")
public class EbookController {

    private final EbookService service;

    public EbookController(EbookService service) {
        this.service = service;
    }

    @PostMapping
    public Ebook create(@RequestBody Ebook ebook) {
        return service.create(ebook);
    }

    @GetMapping
    public List<Ebook> getAll() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public Ebook getById(@PathVariable String id) {
        return service.getById(id);
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable String id) {
        service.delete(id);
        return "eBook deleted";
    }
}
