package com.ebook.backend.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.ebook.backend.model.Ebook;

public interface EbookRepository extends MongoRepository<Ebook, String> {
}
